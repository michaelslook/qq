# Dependency Confusion PoC

This package simulates a dependency confusion attack by using a scoped name (@yourorg-internal-lib) commonly used internally.

⚠️ DO NOT use in production. Testing only.