# Manifest Confusion PoC

Simulates a scenario where package-lock.json specifies a version different from package.json.