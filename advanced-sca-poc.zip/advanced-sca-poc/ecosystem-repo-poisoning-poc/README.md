# Ecosystem Repo Poisoning PoC

This demonstrates repo poisoning via Git tags in Go modules.