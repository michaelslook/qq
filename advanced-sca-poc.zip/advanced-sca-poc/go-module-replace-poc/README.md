# Go Module Replace PoC

This demonstrates module replacement attack via go.mod 'replace' directive.