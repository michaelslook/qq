# Typosquatting PoC

This package simulates a typosquatting attack (lodas instead of lodash).

⚠️ For demo only. Do not publish to public npm without authorization.