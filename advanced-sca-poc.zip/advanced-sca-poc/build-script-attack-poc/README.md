# Build Script Attack PoC

This demonstrates a malicious postinstall script. DO NOT run outside a controlled test environment.