package main

import (
  "fmt"
  "github.com/example/securelib"
)

func main() {
  fmt.Println(securelib.SecureFunc())
}