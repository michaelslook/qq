# Sigstore Spoofing PoC

Simulates a supply chain attack bypassing Sigstore verification via forged signatures (PoC based on BlackHat 2024 research).